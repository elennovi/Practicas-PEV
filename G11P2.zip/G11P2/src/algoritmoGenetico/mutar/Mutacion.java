package algoritmoGenetico.mutar;

import algoritmoGenetico.individuos.Individuo;

public abstract class Mutacion {
	
	public abstract void mutar(Individuo i);
}
